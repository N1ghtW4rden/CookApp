//
//  DetailInterfaceController.swift
//  MyCookApp WatchKit Extension
//
//  Created by Горохов Никита Исип20 on 06.04.2022.
//

import WatchKit
import Foundation

class DetailInterfaceController: NSObject {
    
    @IBOutlet var iconLabel: WKInterfaceLabel!
    @IBOutlet var nameLabel: WKInterfaceLabel!
    @IBOutlet var recipeImage: WKInterfaceImage!
    @IBOutlet var recipeTitle: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        if let model = context as? Recipes {
            
            iconLabel.setText(String(model.emojiRecipe))
            nameLabel.setText(model.nameRecipe)
            recipeImage.setImageNamed(model.imageRecipe)
            recipeTitle.setText(model.recipeRecipe)
            
        }
        
    }
    
}
