//
//  TableRow.swift
//  MyCookApp WatchKit Extension
//
//  Created by Efremov on 04.04.2022.
//

import WatchKit
import Foundation

class TableRow: NSObject {
    
    @IBOutlet weak var recipeNameLabel: WKInterfaceLabel!
    @IBOutlet weak var recipeIconLabel: WKInterfaceLabel!
    
}
